describe('empty spec', () => {

  beforeEach(() => {
    cy.visit('http://127.0.0.1:5173/')
  })

  it('empty', () => {

  })

})